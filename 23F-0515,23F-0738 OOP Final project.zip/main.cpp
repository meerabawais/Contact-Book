#include "Address.h"
#include "Contact.h"
#include "ContactsBook.h"
void GroupMenu()
{
	cout << "\nGROUP MENU\n";
	cout << "\n\n1. Create a new Group\n";
	cout << "2. Add a Contact to a Group\n";
	cout << "3. Remove a Contact from a Group\n";
	cout << "4. Display All Contacts in a Group\n";
	cout << "5. Delete a Group\n";
	cout << "6. Return to Main Menu\n";
	cout << "\nEnter choice: ";
}

void Menu()
{
	cout << "\nCONTACT MENU\n";
	cout << "\n\n1.  Add Contact\n2.  Merge Duplicates\n";
	cout << "3.  Store to file\n4.  Load from file\n";
	cout << "5.  Print Contacts Sorted\n6.  Print / delete / update contacts\n";
	cout << "7.  Search contacts\n8.  Display count of contacts\n";
	cout << "9.  Manage Groups\n10. Search History\n11. Exit Program\n";
	cout << "\nEnter choice: ";
}


Contact takeInputs(Contact& tempContact)
{
	string first, last, mobile, email;
	string house, street, city, country;
	Address tempAddress;

	cout << "First Name: ";
	cin.ignore();
	getline(cin, first);
	tempContact.setFirstName(first);

	cout << "Last Name: ";
	getline(cin, last);
	tempContact.setLastName(last);

	cout << "Mobile Number: ";
	getline(cin, mobile);
	if (mobile.size() > 11 || mobile.size() < 11)
	{
		do
		{
			cout << "\nInvalid Number!\nEnter a valid Number: ";
			getline(cin, mobile);
		} while (mobile.size() != 11);
	}

	tempContact.setMobileNumber(mobile);

	cout << "Email Address: ";
	getline(cin, email);
	tempContact.setEmail(email);

	cout << "House Number: ";
	getline(cin, house);
	tempAddress.setHouse(house);

	cout << "Street: ";
	getline(cin, street);
	tempAddress.setStreet(street);

	cout << "City: ";
	getline(cin, city);
	tempAddress.setCity(city);

	cout << "Country: ";
	getline(cin, country);
	tempAddress.setCountry(country);

	tempContact.setAddress(&tempAddress);

	return tempContact;

}

int main()
{
	bool ProgramEnd = false;
	int menuChoice, searchChoice, delContChoice;
	int groupChoice;

	string first, last, mobile, email;
	string house, street, city, country;

	SearchHistory history;
	ContactsBook contactbook;
	Address tempAddress, findAddress;
	Contact tempContact;


	while (!ProgramEnd)
	{
		Menu();
		cin >> menuChoice;

		if (menuChoice == 1)
		{

			cout << "\nEnter details of contact you want to add:\n";
			contactbook.add_contact(takeInputs(tempContact));

			cout << endl;
			system("pause");
			system("cls");

		}

		else if (menuChoice == 2)
		{
			contactbook.merge_duplicates();
			cout << endl;
			system("pause");
			system("cls");
		}

		else if (menuChoice == 3)
		{
			contactbook.save_to_file();
			cout << endl;
			system("pause");
			system("cls");

		}

		else if (menuChoice == 4)
		{
			contactbook.input_from_file();

			cout << endl;
			system("pause");
			system("cls");

		}

		else if (menuChoice == 5)
		{
			cout << "\n1. Sort All by first names\n2. Sort All by last name\n";
			cout << "\nEnter your chocie: ";
			cin >> searchChoice;

			contactbook.print_contacts_sorted(searchChoice);

			cout << endl;
			system("pause");
			system("cls");
		}

		else if (menuChoice == 6)
		{
			contactbook.printAllContacts();
			cout << "\n1. To view/update/delete a specific contact\n";
			cout << "2. Continue";
			cout << "\n\nEnter choice : ";
			cin >> searchChoice;

			if (searchChoice == 1)
			{
				cout << "Enter contact number you want the details of: ";
				cin >> delContChoice;
				contactbook.printSpecificContact(delContChoice);
				cout << "\n1. To delete contact";
			
				cout << "\n2. To update contact";
				
				cout << "\n3. Continue\n\n";
				
				cout << "Enter your choice: ";
				cin >> menuChoice;

				if (menuChoice == 1)
				{
					contactbook.deleteContact(delContChoice);
					cout << endl;
					system("pause");
					system("cls");
					continue;
				}
				else if (menuChoice == 2)
				{
					cout << "\nEnter the new updated info:\n";

					contactbook.updateContact(delContChoice, takeInputs(tempContact));

					cout << endl;
					system("pause");
					system("cls");
					continue;
				}
				else if (menuChoice == 3)
				{
					system("cls");
					continue;
				}
				else
				{
					cout << "\nInvalid input\n";
				}


			}
			else if (searchChoice == 2)
			{
				system("cls");
				continue;

			}
			else
			{
				cout << "Invalid input\n";
			}

			cout << endl;
			system("pause");
			system("cls");
		}

		else if (menuChoice == 7)
		{
			system("cls");
			cout << "\n1. Search by Name\n2. Search by Mobile number";
			cout << "\n3. Search by Address\n4. General Search\n5. Advance Search\n\nEnter your choice: ";
			cin >> searchChoice;

			if (searchChoice == 1)
			{

				cout << "\nEnter the name of person you want to find:\n";
				cout << "First Name: ";
				cin >> first;
				cout << "Last Name: ";
				cin >> last;

				string combinedName = first + " " + last;

				history.SearchBox(combinedName);

				cout << endl;
				if (contactbook.search_contact(first, last) != nullptr)
				{
					contactbook.search_contact(first, last)->printContactInfo();
				}

				cout << endl;

				system("pause");
				system("cls");

			}

			else if (searchChoice == 2)
			{

				cout << "Enter mobile number of the person you want to find: ";
				cin.ignore();
				getline(cin, mobile);

				history.SearchBox(mobile);

				cout << endl;
				if (contactbook.search_contact(mobile) != nullptr)
				{
					contactbook.search_contact(mobile)->printContactInfo();
				}

				cout << endl;

				system("pause");
				system("cls");

			}

			else if (searchChoice == 3)
			{
				cout << "Enter the address of person you want to find:\n";
				cout << "House Number: ";
				cin >> house;
				findAddress.setHouse(house);

				cout << "Street: ";
				cin >> street;
				findAddress.setStreet(street);

				cout << "City: ";
				cin >> city;
				findAddress.setCity(city);

				cout << "Country: ";
				cin >> country;
				findAddress.setCountry(country);

				string combineAddress = "House No. " + house + ", Street " + street + ", " + city + ", " + country;
				history.SearchBox(combineAddress);


				cout << endl;
				if (contactbook.search_contact(&findAddress) != nullptr)
				{
					contactbook.search_contact(&findAddress)->printContactInfo();
				}

				cout << endl;

				system("pause");
				system("cls");

			}
			else if (searchChoice == 4)
			{
				cout << "Enter any info of contact to find: ";
				cin.ignore();
				getline(cin, first);

				history.SearchBox(first);

				if (contactbook.general_search(first) != nullptr)
				{
					contactbook.general_search(first)->printContactInfo();
				}

				cout << endl;

				system("pause");
				system("cls");
			}
			else if (searchChoice == 5)
			{
				contactbook.advance_search();

				cout << endl;

				system("pause");
				system("cls");
			}


			else
			{
				cout << "\nInvalid Input\n";
				system("pause");
				system("cls");
			}
		}

		else if (menuChoice == 8)
		{
			cout << "\nTotal number of contacts saved in contact book = " << contactbook.total_contacts() << endl;

			cout << endl;
			system("pause");
			system("cls");
		}

		else if (menuChoice == 9)
		{
			while (true)
			{
				system("cls");
				GroupMenu();
				cin >> groupChoice;
				if (groupChoice == 1)
				{
					cout << "\nEnter name of your group: ";
					cin.ignore();
					getline(cin, first);

					contactbook.createGroup(first);

					cout << endl;
					system("pause");
					system("cls");

				}
				else if (groupChoice == 2)
				{
					cout << "Enter name of group you want to add contacts in: ";
					cin.ignore();
					getline(cin, first);


					cout << "\nEnter details of contact you want to add:\n";
					contactbook.addContactToGroup((takeInputs(tempContact)), first);

					cout << endl;
					system("pause");
					system("cls");
				}
				else if (groupChoice == 3)
				{


					contactbook.removeContactfromGroup();

					cout << endl;
					system("pause");
					system("cls");
				}
				else if (groupChoice == 4)
				{
					system("cls");
					contactbook.printGroupContacts();

					cout << endl;
					system("pause");
					system("cls");
				}

				else if (groupChoice == 5)
				{
					cout << "Enter name of group you want to delete: ";
					cin.ignore();
					getline(cin, first);

					contactbook.deleteGroup(first);

					cout << endl;
					system("pause");
					system("cls");
				}

				else if (groupChoice == 6)
				{
					system("cls");
					break;
				}

				else
				{
					cout << "\nInvalid Input\n";

					system("pause");
					system("cls");
				}
				system("cls");
			}
		}

		else if (menuChoice == 10)
		{
			history.displayHistory();

			cout << endl;
			system("pause");
			system("cls");
		}

		else if (menuChoice == 11)
		{
			ProgramEnd = true;
		}

		else
		{
			cout << "\nInvalid Input\n";

			system("pause");
			system("cls");
		}

	}

	cout << "\nProgram Ended\n";
	cout << endl;
	system("pause");
	return 0;
}