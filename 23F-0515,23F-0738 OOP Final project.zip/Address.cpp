#include "Address.h"
Address::Address()
{
	house = "";
	street = "";
	city = "";
	country = "";
}

Address::Address(string h, string s, string ci, string c)
{
	house = h;
	street = s;
	city = ci;
	country = c;
}

string Address::getHouse() {
	return house;
}
string Address::getStreet() {
	return street;
}
string Address::getCity() { 
	return city;
}
string Address::getCountry() {
	return country;
}
void Address::setHouse(string h) {
	house = h;
}
void Address::setStreet(string s) {
	street = s; 
}
void Address::setCity(string ci) { 
	city = ci; 
}
void Address::setCountry(string c) { 
	country = c; 
}

bool Address::equals(const Address& address)
{
	if (this->house == address.house &&
		this->street == address.street &&
		this->city == address.city &&
		this->country == address.country)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void Address::print_address()
{
	cout << "House No. " << house << ", Street " << street << ", " << city << ", " << country;
}

Address Address::copy_address()
{
	Address* temp = new Address;

	temp->house = this->house;
	temp->street = this->street;
	temp->city = this->city;
	temp->country = this->country;
	return *temp;
}
