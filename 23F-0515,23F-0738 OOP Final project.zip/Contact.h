#pragma once
#ifndef BASIC_LIB
#define BASIC_LIB
#include <iostream>
#include <string>
#endif // !BASIC_LIB

#include "Address.h"
using namespace std;
class Contact
{
private:
	string first_name;
	string last_name;
	string mobile_number;
	string email_address;
	Address* address;

public:
	Contact();
	Contact(string first, string last, string mobile, string email, Address* add);
	Contact(const Contact& other);

	string getFirstName();
	string getLastName();
	string getMobileNumber();
	string getEmailAddress();
	Address* getAddress();
	void setFirstName(string first);
	void setLastName(string last);
	void setMobileNumber(string mobile);
	void setEmail(string email);
	void setAddress(Address* add);

	bool equals(Contact contact);
	Contact* copy_contact();
	void printContactInfo();
};

