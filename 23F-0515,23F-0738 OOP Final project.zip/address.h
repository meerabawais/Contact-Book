#pragma once
#include <iostream>
#include <string>
using namespace std;
class Address
{
private:
	string house;
	string street;
	string city;
	string country;

public:
	Address();
	Address(string h, string s, string ci, string c);

	string getHouse();
	string getStreet();
	string getCity();
	string getCountry();
	void setHouse(string h);
	void setStreet(string s);
	void setCity(string ci);
	void setCountry(string c);

	bool equals(const Address& address);
	void print_address();
	Address copy_address();

};
