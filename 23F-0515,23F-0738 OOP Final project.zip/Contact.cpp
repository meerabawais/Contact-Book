#include "Contact.h"
Contact::Contact()
{
	first_name = "";
	last_name = "";
	mobile_number = "";
	email_address = "";
	address = nullptr;
}
Contact::Contact(string first, string last, string mobile, string email, Address* add)
{
	if (!first.empty()) {
		first_name = first;
	}
	if (!last.empty()) {
		last_name = last;
	}
	if (mobile.size() == 11) {
		mobile_number = mobile;
	}
	email_address = email;
	address->setHouse(add->getHouse());
	address->setStreet(add->getStreet());
	address->setCity(add->getCity());
	address->setCountry(add->getCountry());
}
Contact::Contact(const Contact& other)
{
	this->first_name = other.first_name;
	this->last_name = other.last_name;
	this->mobile_number = other.mobile_number;
	this->email_address = other.email_address;
	this->address = new Address;
	/*this->address = other.address;*/
	this->address->setCity(other.address->getCity());
	this->address->setCountry(other.address->getCountry());
	this->address->setHouse(other.address->getHouse());
	this->address->setStreet(other.address->getStreet());

}

string Contact::getFirstName() { return first_name; }
string Contact::getLastName() { return last_name; }
string Contact::getMobileNumber() { return mobile_number; }
string Contact::getEmailAddress() { return email_address; }
Address* Contact::getAddress() { return address; }

void Contact::setFirstName(string first) {
	if (!first.empty()) {
		first_name = first;
	}
}

void Contact::setLastName(string last) {
	if (!last.empty()) {
		last_name = last;
	}
}

void Contact::setMobileNumber(string mobile) {
	if (mobile.size() == 11) {
		mobile_number = mobile;
	}
}

void Contact::setEmail(string email) {
	email_address = email;
}

void Contact::setAddress(Address* add) {
	address = add;
}

bool Contact::equals(Contact contact) {
	if (this->first_name == contact.first_name &&
		this->last_name == contact.last_name &&
		this->mobile_number == contact.mobile_number &&
		this->email_address == contact.email_address &&
		this->address->equals(*(contact.address)))
	{
		return true;
	}
	return false;
}

Contact* Contact::copy_contact() {

	Contact* newContact = new Contact;
	newContact->first_name = this->first_name;
	newContact->last_name = this->last_name;
	newContact->mobile_number = this->mobile_number;
	newContact->email_address = this->email_address;
	newContact->address = this->address;

	return newContact;
}

void Contact::printContactInfo()
{
	cout << "Name: " << first_name << " " << last_name << endl;
	cout << "Mobile Number: " << mobile_number << endl;
	cout << "Email Address: " << email_address << endl;
	cout << "Address: ";
	address->print_address();
	cout << endl;

}
