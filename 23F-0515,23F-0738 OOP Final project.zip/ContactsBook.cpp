#include "ContactsBook.h"
#include <fstream>
Group::Group() {
	groupName = " ";
	capacity = 0;
	size=0;
}
Group::Group(string name, int cap = 20) : capacity(cap) {
	groupName = name;
	groupContacts = new Contact * [capacity];//array of pointers to contact objects
}

Group::~Group() {
	for (int i = 0; i < size; ++i) {
		delete groupContacts[i];
		groupContacts[i] = nullptr; // Set pointer to nullptr after deletion
	}
	delete[] groupContacts;
}

bool Group::checkGroup(const Group& others)
{
	if (this->groupName == others.groupName)
	{
		return true;
	}

}

string Group::getGroupName() { return groupName; }

void Group::addContact(Contact* contact) {
	if (contact != nullptr) {
		if (size < capacity) {
			groupContacts[size++] = new Contact(*contact);
			cout << "Contact added to group '" << groupName << "' successfully." << endl;
		}
		else {
			cout << "Group capacity reached. Cannot add more contacts." << endl;
		}
	}
	else {
		cout << "Invalid contact. Cannot add to group." << endl;
	}
}

void Group::removeContact(int num) {
	if (num >= 1 && num <= capacity && groupContacts[num - 1] != nullptr) {
		delete groupContacts[num - 1];

		for (int i = num - 1; i < size - 1; i++) {
			groupContacts[i] = groupContacts[i + 1];
		}
		groupContacts[size - 1] = nullptr; // Update the last element to nullptr
		size--;

		cout << "Contact removed from group '" << groupName << "' successfully." << endl;
	}
	else {
		cout << "Invalid contact number or contact not found." << endl;
	}
}

int Group::findContactIndex(string contactName) {
	for (int i = 0; i < size; ++i) {
		if (groupContacts[i]->getFirstName() == contactName) {
			return i;
		}
	}
	return -1; // Return -1 if contact not found
}

void Group::displayContacts() {
	cout << "Contacts in group '" << groupName << "':" << endl;
	for (int i = 0; i < size; i++) {
		cout << "\nContact " << i + 1 << ":\n";
		groupContacts[i]->printContactInfo();
		cout << endl;
	}
}

bool ContactsBook::full()
{
	if (contacts_count == size_of_contacts) {
		return true;
	}
	else
	{
		return false;
	}
}

void ContactsBook::resize_list() {

	//double the size of array
	int newSize = size_of_contacts * 2;
	Contact* new_contacts_list = new Contact[newSize];

	//copy existing contacts to the new array
	for (int i = 0; i < contacts_count; i++) {
		new_contacts_list[i] = *contacts_list[i];
	}

	// Free memory allocated for the old contacts list
	*contacts_list = new_contacts_list;
	delete[] contacts_list;

}

void ContactsBook::sort_contacts_list(int choice)
{
	for (int i = 0; i < contacts_count - 1; ++i)
	{
		for (int j = 0; j < contacts_count - i - 1; ++j)
		{
			// if sort by first name
			if (choice == 1)
			{
				if (contacts_list[j]->getFirstName() > contacts_list[j + 1]->getFirstName())
				{
					//swap contacts
					Contact* temp = contacts_list[j];
					contacts_list[j] = contacts_list[j + 1];
					contacts_list[j + 1] = temp;
				}
			}
			// if sort by last name
			else if (choice == 2)
			{
				if (contacts_list[j]->getLastName() > contacts_list[j + 1]->getLastName())
				{
					// swap contacts
					Contact* temp = contacts_list[j];
					contacts_list[j] = contacts_list[j + 1];
					contacts_list[j + 1] = temp;
				}
			}
		}
	}
}

ContactsBook::ContactsBook()
{
	for (int i = 0; i < 100; ++i) {
		groups[i] = nullptr;
	}
	for (int i = 0; i < size_of_contacts; i++)
	{

		contacts_list[i] = nullptr;
	}
}

void ContactsBook::add_contact(const Contact& contact) {
	if (full()) {
		resize_list();
	}

	contacts_list[contacts_count] = new Contact(contact);
	cout << "\nContact has been added successfully\n";
	contacts_count++;
}

int ContactsBook::total_contacts() {
	return contacts_count;
}

Contact* ContactsBook::search_contact(string first_name, string last_name) {
	bool flag = false;
	for (int i = 0; i < contacts_count; i++) {
		if (contacts_list[i]->getFirstName() == first_name && contacts_list[i]->getLastName() == last_name) {
			flag = true;
			//return a copy of the found contact
			return new Contact(*(contacts_list[i]));
		}
	}
	if (!flag)
	{
		cout << "\nNo Contact found with such name\n";
		return nullptr; //contact not found
	}
}

Contact* ContactsBook::search_contact(string mobile) {
	bool flag = false;
	for (int i = 0; i < contacts_count; ++i) {
		if (contacts_list[i]->getMobileNumber() == mobile) {
			flag = true;
			//return a copy of the found contact
			return new Contact(*(contacts_list[i]));
		}
	}
	if (!flag)
	{
		cout << "\nNo Contact found with such number\n";
		//no cont found
		return nullptr;
	}
}

Contact* ContactsBook::search_contact(Address* add) {
	bool flag = false;
	for (int i = 0; i < contacts_count; i++) {
		if (contacts_list[i]->getAddress()->equals(*add)) {
			flag = true;
			//return a copy of the found contact
			return new Contact(*(contacts_list[i]));
		}
	}
	if (!flag) {
		cout << "\nNo Contact found with such address\n";
		return nullptr; // Contact not found
	}
}

Contact* ContactsBook::general_search(string general)
{
	for (int i = 0; i < contacts_count; i++)
	{
		if (contacts_list[i]->getFirstName() == general || contacts_list[i]->getLastName() == general || contacts_list[i]->getEmailAddress() == general || contacts_list[i]->getMobileNumber() == general)
		{
			return new Contact(*(contacts_list[i]));
		}
		else if (contacts_list[i]->getAddress()->getHouse() == general || contacts_list[i]->getAddress()->getStreet() == general || contacts_list[i]->getAddress()->getCity() == general || contacts_list[i]->getAddress()->getCountry() == general)
		{
			return new Contact(*(contacts_list[i]));
		}
	}
	cout << "\nNo Contact found with such detail\n";
	return nullptr;
}

void ContactsBook::printAllContacts()
{
	for (int i = 0; i < contacts_count; i++)
	{
		cout << "\nContact " << i + 1 << ":\n";
		contacts_list[i]->printContactInfo();
		cout << endl;
	}
}

void ContactsBook::printSpecificContact(int num)
{
	if (contacts_list[num - 1] == nullptr)
	{
		cout << "\nNo contact found at " << num << endl;
		return;
	}
	cout << "\nContact: " << num << ":\n";
	contacts_list[num - 1]->printContactInfo();
}

void ContactsBook::print_contacts_sorted(int choice) {
	sort_contacts_list(choice);

	for (int i = 0; i < contacts_count; i++)
	{
		cout << "\nContact " << i + 1 << ":\n";
		contacts_list[i]->printContactInfo();
		cout << endl;
	}
}

void ContactsBook::deleteContact(int num)
{
	cout << "\nContact number " << num << " has been deleted successfully\n";
	delete contacts_list[num - 1];

	//tp fill the space
	for (int i = num - 1; i < contacts_count - 1; i++) {
		contacts_list[i] = contacts_list[i + 1];
	}
	contacts_count--;
}

void ContactsBook::updateContact(int num, Contact contact)
{
	delete contacts_list[num - 1];
	contacts_list[num - 1] = new Contact(contact);

	cout << "\nContact " << num << " has been updated\n";
}

void ContactsBook::merge_duplicates()
{
	bool flag = false;
	for (int i = 0; i < contacts_count; i++)
	{
		for (int j = i + 1; j < contacts_count; j++)
		{
			if (contacts_list[i]->equals(*contacts_list[j]))
			{
				cout << "\nA duplicate contact has been found and both are merged\n";
				delete contacts_list[j];
				flag = true;


				//to fill up the space
				for (int k = j; k < contacts_count - 1; k++) {
					contacts_list[k] = contacts_list[k + 1];
				}

				contacts_count--;
				j--;
			}
		}
	}

	if (!flag)
	{
		cout << "\nNo duplicate contact found!\n";
	}
}

void ContactsBook::save_to_file() {
	ofstream outfile("outfile.txt");


	if (!outfile.is_open()) {
		cout << "\nError! File can not be openned" << endl;
		return;
	}

	for (int i = 0; i < contacts_count; i++) {
		outfile << "Contact " << i + 1 << ":\n";
		outfile << "Name: " << contacts_list[i]->getFirstName() << " " << contacts_list[i]->getLastName() << endl;
		outfile << "Mobile Number: " << contacts_list[i]->getMobileNumber() << endl;
		outfile << "Address: House No. " << contacts_list[i]->getAddress()->getHouse() << ", Street ";
		outfile << contacts_list[i]->getAddress()->getStreet() << ", " << contacts_list[i]->getAddress()->getCity();
		outfile << ", " << contacts_list[i]->getAddress()->getCountry() << endl << endl;
	}

	outfile.close();
	cout << "\nContacts saved to file successfully\n";
}

void ContactsBook::input_from_file() {
	ifstream infile("infile.txt");
	string line;

	if (!infile.is_open()) {
		cout << "\nError! File can not be openned" << endl;
		return;
	}

	cout << "\nContacts from file:" << endl;
	while (getline(infile, line)) {
		cout << line << endl;
	}

	infile.close();
}

void ContactsBook::advance_search() {
	string advance_string, store_string;
	int count = 0, k = 0, x = 0, contact_count = 0;
	cout << "Enter your input (without space): ";
	cin >> advance_string;
	for (int n = 0; n < contacts_count; n++)
	{
		store_string = contacts_list[n]->getFirstName();
		for (int i = 0; i < strlen(advance_string.c_str()); i++)
		{
			for (int j = 0; j < strlen(store_string.c_str()); j++)
			{
				if (store_string[j] == advance_string[i] && k < j) {
					count++;
					k = j;
					x = i;
				}
			}

		}
		store_string = contacts_list[n]->getLastName();
		k = 0;
		for (int i = x; i < strlen(advance_string.c_str()); i++)
		{
			for (int j = 0; j < strlen(store_string.c_str()); j++)
			{
				if (store_string[j] == advance_string[i] && k < j) {
					count++;
					k = j;
				}
			}

		}
		if (count == strlen(advance_string.c_str()))
		{
			cout << "\nFirst Name: " << contacts_list[n]->getFirstName() << endl;
			cout << "Last Name: " << contacts_list[n]->getLastName() << endl;
			cout << "Mobile no.: " << contacts_list[n]->getMobileNumber() << endl;
			cout << "Email: " << contacts_list[n]->getEmailAddress() << endl;
			cout << "Address: " << endl;
			cout << "House: " << contacts_list[n]->getAddress()->getHouse() << endl;
			cout << "Street: " << contacts_list[n]->getAddress()->getStreet() << endl;
			cout << "City: " << contacts_list[n]->getAddress()->getCity() << endl;
			cout << "Country: " << contacts_list[n]->getAddress()->getCountry() << endl;
			//	cout << "Group: " << contacts_list[n]->getGroup() << endl << endl;
			cout << endl;
			contact_count++;
		}
	}
	count = 0;
	for (int n = 0; n < contacts_count; n++)
	{
		store_string = contacts_list[n]->getMobileNumber();
		for (int i = 0; i < strlen(advance_string.c_str()); i++)
		{
			for (int j = 0; j < strlen(store_string.c_str()); j++)
			{
				if (store_string[j] == advance_string[i] && k < j) {
					count++;
					k = j;
					x = i;
				}
			}

		}

		if (count == strlen(advance_string.c_str()))
		{
			cout << "\nFirst Name: " << contacts_list[n]->getFirstName() << endl;
			cout << "Last Name: " << contacts_list[n]->getLastName() << endl;
			cout << "Mobile no.: " << contacts_list[n]->getMobileNumber() << endl;
			cout << "Email: " << contacts_list[n]->getEmailAddress() << endl;
			cout << "Address: " << endl;
			cout << "House: " << contacts_list[n]->getAddress()->getHouse() << endl;
			cout << "Street: " << contacts_list[n]->getAddress()->getStreet() << endl;
			cout << "City: " << contacts_list[n]->getAddress()->getCity() << endl;
			cout << "Country: " << contacts_list[n]->getAddress()->getCountry() << endl;
			//	cout << "Group: " << contacts_list[n]->getGroup() << endl << endl;
			cout << endl;
			contact_count++;
		}
	}
	count = 0;
	for (int n = 0; n < contacts_count; n++)
	{
		store_string = contacts_list[n]->getEmailAddress();
		for (int i = 0; i < strlen(advance_string.c_str()); i++)
		{
			for (int j = 0; j < strlen(store_string.c_str()); j++)
			{
				if (store_string[j] == advance_string[i] && k < j) {
					count++;
					k = j;
					x = i;
				}
			}

		}
		store_string = contacts_list[n]->getLastName();
		k = 0;

		if (count == strlen(advance_string.c_str()))
		{
			cout << "\nFirst Name: " << contacts_list[n]->getFirstName() << endl;
			cout << "Last Name: " << contacts_list[n]->getLastName() << endl;
			cout << "Mobile no.: " << contacts_list[n]->getMobileNumber() << endl;
			cout << "Email: " << contacts_list[n]->getEmailAddress() << endl;
			cout << "Address: " << endl;
			cout << "House: " << contacts_list[n]->getAddress()->getHouse() << endl;
			cout << "Street: " << contacts_list[n]->getAddress()->getStreet() << endl;
			cout << "City: " << contacts_list[n]->getAddress()->getCity() << endl;
			cout << "Country: " << contacts_list[n]->getAddress()->getCountry() << endl;
			//	cout << "Group: " << contacts_list[n]->getGroup() << endl << endl;
			cout << endl;
			contact_count++;
		}
	}


	cout << contact_count << " Contacts Found!" << endl;

}

void ContactsBook::createGroup(string groupName) {
	if (groups_count < 100) {
		groups[groups_count] = new Group(groupName);
		groups_count++;
		cout << "\nGroup '" << groupName << "' created successfully." << endl;
	}
	else {
		cout << "\nMaximum number of groups reached. Cannot create more groups." << endl;
	}
}

void ContactsBook::addContactToGroup(Contact contact, string groupName) {
	for (int i = 0; i < groups_count; i++) {
		if (groups[i]->checkGroup(groupName)) {
			groups[i]->addContact(&contact);
			return;
		}
	}
	cout << "Group '" << groupName << "' not found." << endl;
}

void ContactsBook::removeContactfromGroup()
{
	string name;
	int num;
	bool flag = false;

	cout << "Enter name of group you want to remove contacts from: ";
	cin.ignore();
	getline(cin, name);


	for (int i = 0; i < groups_count; i++)
	{
		if (groups[i]->getGroupName() == name) {
			system("cls");
			groups[i]->displayContacts();
			flag = true;
		}
	}
	if (!flag)
	{
		cout << "\nNo gorup found with name " << name << endl;
		return;
	}

	cout << "\nEnter number of contact you want to delete in the group: ";
	cin >> num;

	for (int i = 0; i < groups_count; i++)
	{

		if (groups[i]->checkGroup(name)) {
			groups[i]->removeContact(num);
			return;
		}
	}
	cout << "Group '" << name << "' not found." << endl;
}

void ContactsBook::printGroupContacts()
{
	for (int i = 0; i < groups_count; i++)
	{
		cout << "Group " << i + 1 << ":\n";
		groups[i]->displayContacts();
	}
}

void ContactsBook::deleteGroup(string groupName) {
	int index = -1;
	for (int i = 0; i < groups_count; i++) {
		if (groups[i]->getGroupName() == groupName) {
			index = i;
			break;
		}
	}
	if (index != -1) {
		delete groups[index];

		for (int i = index; i < groups_count - 1; ++i) {
			groups[i] = groups[i + 1];
		}
		groups_count--;
		cout << "Group '" << groupName << "' deleted successfully." << endl;
	}
	else {
		cout << "Group '" << groupName << "' not found." << endl;
	}
}

int ContactsBook::contacts_count = 0;


void SearchHistory::SearchBox(string hist)
{
	if (historyCount < 100)
	{
		history[historyCount] = hist;
		historyCount++;
	}
	if (historyCount >= 6)
	{
		for (int i = 0; i < 5; i++) {
			history[i] = history[i + 1];
		}
		historyCount--;
	}

}

void SearchHistory::displayHistory()
{
	int n, count = 1;
	if (historyCount < 6)
	{
		n = historyCount - 1;
	}
	else if (historyCount >= 5)
	{
		n = 4;
	}

	cout << "\nSearch history:\n";
	for (int i = n; i >= 0; i--)
	{
		cout << count << ". ";
		cout << history[i] << endl;
		count++;
	}
	count = 1;
}

int SearchHistory::historyCount = 0;
