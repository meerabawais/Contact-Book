#pragma once
#include "Address.h"
#include "Contact.h"

#ifndef BASIC_LIB
#define BASIC_LIB
#include <iostream>
#include <string>
	using namespace std;
#endif // !BASIC_LIB

class Group {
private:
	string groupName;
	Contact** groupContacts;
	int capacity;
	int size;

public:
	Group();
	Group(string name, int cap);
	~Group();
	bool checkGroup(const Group& others);
	string getGroupName();
	void addContact(Contact* contact);
	void removeContact(int num);
	int findContactIndex(string contactName);
	void displayContacts();
	};

class ContactsBook {
private:
	static const int size_of_contacts = 100;
	Contact* contacts_list[size_of_contacts];
	static int contacts_count;
	Group* groups[100];
	int groups_count = 0;
	bool full();
	void resize_list();
	void sort_contacts_list(int choice);
public:
	ContactsBook();
	void add_contact(const Contact& contact);
	int total_contacts();
	Contact* search_contact(string first_name, string last_name);
	Contact* search_contact(string mobile);
	Contact* search_contact(Address* add);
	Contact* general_search(string general);
	void printAllContacts();
	void printSpecificContact(int num);
	void print_contacts_sorted(int choice);
	void deleteContact(int num);
	void updateContact(int num, Contact contact);
	void merge_duplicates();
	void save_to_file();
	void input_from_file();
	void advance_search();
	void createGroup(string groupName);
	void addContactToGroup(Contact contact, string groupName);
	void removeContactfromGroup();
	void printGroupContacts();
	void deleteGroup(string groupName);
};
class SearchHistory
{
	string history[100];
	static int historyCount;
public:
	void SearchBox(string hist);
	void displayHistory();
};


